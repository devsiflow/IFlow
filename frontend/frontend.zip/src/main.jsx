import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.jsx";
import "aos/dist/aos.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Cadastro from "./pages/Sign-inPage.jsx";
import Login from "./pages/LoginPage.jsx";
import Catalogo from "./pages/Catalogo.jsx";
import CadastraItem from "./pages/CadastrarItem.jsx";
import ValidarItem from "./pages/ValidarItem.jsx";
import ValidacaoConfirmada from "./pages/ValidacaoConfirmada.jsx";
import UserPage from "./pages/UserPage.jsx";
import ItemPage from "./pages/ItemPage.jsx";
import AdminPage from "./admin/AdminPage.jsx";
import { ThemeProvider } from "./context/ThemeContext.jsx";


const router = createBrowserRouter([
  {
    path: "/validacao/:id",  // <-- adiciona :id
    element: <ValidarItem />,
  },
  {
    path: "/validacaoConfirmada",
    element: <ValidacaoConfirmada />,
  },
  {
    path: "/itempage/:id",
    element: <ItemPage />,
  },{
    path: "/",
    element: <App />,
  },
  {
    path: "/admin",
    element: <AdminPage />,
  },
  {
    path: "/home",
    element: <App />,
  },
  {
    path: "/cadastro",
    element: <Cadastro />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/catalogo",
    element: <Catalogo />,
  },
  {
    path: "/cadastroitem",
    element: <CadastraItem />,
  },
  {
    path: "/perfil",
    element: <UserPage />,
  },
  {
    path: "/itempage/:id",
    element: <ItemPage />,
  },
]);

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <ThemeProvider>
      <RouterProvider router={router} />
    </ThemeProvider>
  </StrictMode>
);
