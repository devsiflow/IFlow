-- AlterTable
ALTER TABLE "public"."Profile" ADD COLUMN     "isAdmin" BOOLEAN NOT NULL DEFAULT false;
