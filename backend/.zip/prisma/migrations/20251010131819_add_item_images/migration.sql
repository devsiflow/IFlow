-- AlterTable
ALTER TABLE "public"."Item" ADD COLUMN     "imageUrl" TEXT,
ADD COLUMN     "thumbnailUrl" TEXT;
