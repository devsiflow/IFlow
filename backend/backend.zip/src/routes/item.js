import express from "express";
import prisma from "../lib/prismaClient.js";
import { authenticateToken } from "../middleware/auth.js";
import multer from "multer";
import sharp from "sharp";
import fs from "fs";
import path from "path";

const router = express.Router();
const upload = multer({ dest: "uploads/" });

router.post("/", authenticateToken, upload.array("images", 5), async (req, res) => {
  try {
    const { title, description, location, local, categoryName } = req.body;

    if (!title || !description || (!location && !local) || !categoryName) {
      return res.status(400).json({ error: "Campos obrigatórios faltando" });
    }

    const finalLocation = location || local;

    // Verifica ou cria categoria
    let category = await prisma.category.findUnique({ where: { name: categoryName } });
    if (!category) category = await prisma.category.create({ data: { name: categoryName } });

    // Verifica perfil
    const profile = await prisma.profile.findUnique({ where: { id: req.user.id } });
    if (!profile)
      return res.status(400).json({ error: "Perfil não encontrado. Crie seu perfil antes de cadastrar itens." });

    // Cria o item
    const item = await prisma.item.create({
      data: {
        title,
        description,
        location: finalLocation,
        status: "perdido",
        categoryId: category.id,
        userId: req.user.id,
      },
    });

    // Se houver imagens, salva no ItemImage com miniaturas
    if (req.files && req.files.length > 0) {
      const imagesData = [];

      for (const file of req.files) {
        const originalPath = file.path;
        const fileName = `thumb-${Date.now()}-${file.originalname}`;
        const thumbPath = `uploads/thumbnails/${fileName}`;

        // Gera miniatura 200x200
        await sharp(originalPath)
          .resize(200, 200, { fit: "cover" })
          .jpeg({ quality: 80 })
          .toFile(thumbPath);

        imagesData.push({
          url: "/" + originalPath.replace(/\\/g, "/"),
          thumbnailUrl: "/" + thumbPath.replace(/\\/g, "/"),
          itemId: item.id,
        });
      }

      await prisma.itemImage.createMany({ data: imagesData });
    }

    // Retorna o item com as imagens
    const itemWithImages = await prisma.item.findUnique({
      where: { id: item.id },
      include: { images: true, category: true, user: { select: { id: true, name: true } } },
    });

    res.status(201).json(itemWithImages);
  } catch (err) {
    console.error("Erro ao criar item:", err);
    res.status(500).json({ error: "Erro interno do servidor" });
  }
});

export default router;
