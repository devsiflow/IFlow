-- AlterTable
ALTER TABLE "public"."Item" ADD COLUMN     "thumbnailUrl" TEXT;
