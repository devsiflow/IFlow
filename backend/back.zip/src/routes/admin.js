// backend/src/routes/admin.js
import express from "express";
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import authenticateToken from "../middleware/auth.js";

const prisma = new PrismaClient();
const router = express.Router();

// ✅ Middleware para exigir admin
router.use(authenticateToken);

router.use(async (req, res, next) => {
  try {
    const user = await prisma.profile.findUnique({ where: { id: req.user.id } });
    if (!user?.isAdmin && !user?.isSuperAdmin) {
      return res.status(403).json({ error: "Acesso negado. Apenas administradores." });
    }
    next();
  } catch (err) {
    console.error("Erro de permissão:", err);
    res.status(500).json({ error: "Erro interno de permissão." });
  }
});

// ✅ Listar todos os usuários
router.get("/usuarios", async (req, res) => {
  try {
    const usuarios = await prisma.profile.findMany({
      select: {
        id: true,
        name: true,
        matricula: true,
        email: true,
        isAdmin: true,
        isSuperAdmin: true,
        createdAt: true,
      },
    });
    res.json(usuarios);
  } catch (error) {
    console.error("Erro ao listar usuários:", error);
    res.status(500).json({ error: "Erro ao listar usuários." });
  }
});

// ✅ Editar usuário
router.put("/usuarios/:id", async (req, res) => {
  const { id } = req.params;
  const { name, email, isAdmin, isSuperAdmin } = req.body;
  try {
    const user = await prisma.profile.update({
      where: { id },
      data: { name, email, isAdmin, isSuperAdmin },
    });
    res.json(user);
  } catch (error) {
    console.error("Erro ao editar usuário:", error);
    res.status(500).json({ error: "Erro ao editar usuário." });
  }
});

// ✅ Deletar usuário
router.delete("/usuarios/:id", async (req, res) => {
  const { id } = req.params;
  try {
    await prisma.profile.delete({ where: { id } });
    res.json({ message: "Usuário deletado com sucesso." });
  } catch (error) {
    console.error("Erro ao deletar usuário:", error);
    res.status(500).json({ error: "Erro ao deletar usuário." });
  }
});

// ✅ Redefinir senha
router.post("/usuarios/:id/reset-senha", async (req, res) => {
  const { id } = req.params;
  const { novaSenha } = req.body;
  try {
    const hashed = await bcrypt.hash(novaSenha, 10);
    await prisma.user.update({
      where: { id },
      data: { password: hashed },
    });
    res.json({ message: "Senha redefinida com sucesso." });
  } catch (error) {
    console.error("Erro ao redefinir senha:", error);
    res.status(500).json({ error: "Erro ao redefinir senha." });
  }
});

export default router;
